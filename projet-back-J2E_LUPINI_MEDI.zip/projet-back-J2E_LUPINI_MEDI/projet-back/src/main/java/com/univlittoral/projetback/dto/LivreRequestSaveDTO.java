package com.univlittoral.projetback.dto;

public class LivreRequestSaveDTO {

}
