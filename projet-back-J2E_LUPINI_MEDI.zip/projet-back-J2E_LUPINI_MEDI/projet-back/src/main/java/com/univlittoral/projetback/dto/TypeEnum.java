package com.univlittoral.projetback.dto;

public enum TypeEnum {
	ROMAN, MANGA, BD, POESIE,  NOUVELLE
}