package com.univlittoral.projetback.dto;

public class IndicateurDTO {

	private int nbLivres;
	private int nbAuteurs;
	private int nbGenres;
	
	
	public int getNbLivres() {
		return nbLivres;
	}
	public void setNbLivres(int nbLivres) {
		this.nbLivres = nbLivres;
	}
	public int getNbAuteurs() {
		return nbAuteurs;
	}
	public void setNbAuteurs(int nbAuteurs) {
		this.nbAuteurs = nbAuteurs;
	}
	public int getNbGenres() {
		return nbGenres;
	}
	public void setNbGenres(int nbGenres) {
		this.nbGenres = nbGenres;
	}
	
	
}
