package com.univlittoral.projetback;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ProjetBackApplicationTests {

	@Test
	void contextLoads() {
	}

}
